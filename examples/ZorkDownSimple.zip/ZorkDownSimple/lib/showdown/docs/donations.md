ShowdownJS is a **free** library and it will remain **free forever**.

However, maintaining and improving the library costs time and money.

If you like our work and find it useful, please donate through [PayPal](https://www.paypal.me/tiviesantos).

:heart: :pray: Your contributions are greatly appreciated and will help us with the development of this awesome library.