5. foo
6. bar
7. baz

---

3.  a
2.  b
7.  c
23. d
