Object property names found at: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object

[assign]()

[create]()

[defineProperty]()

[defineProperties]()

[entries]()

[freeze]()

[fromEntries]()

[getOwnPropertyDescriptor]()

[getOwnPropertyDescriptors]()

[getOwnPropertyNames]()

[getOwnPropertySymbols]()

[getPrototypeOf]()

[is]()

[isExtensible]()

[isFrozen]()

[isSealed]()

[keys]()

[preventExtensions]()

[seal]()

[setPrototypeOf]()

[values]()

[prototype.constructor]()

[prototype.__proto__]()

[prototype.__defineGetter__]()

[prototype.__defineSetter__]()

[prototype.__lookupGetter__]()

[prototype.__lookupSetter__]()

[prototype.hasOwnProperty]()

[prototype.isPrototypeOf]()

[prototype.propertyIsEnumerable]()

[prototype.toLocaleString]()

[prototype.toString]()

[prototype.valueOf]()

[constructor]()

[__proto__]()

[__defineGetter__]()

[__defineSetter__]()

[__lookupGetter__]()

[__lookupSetter__]()

[hasOwnProperty]()

[isPrototypeOf]()

[propertyIsEnumerable]()

[toLocaleString]()

[toString]()

[valueOf]()
