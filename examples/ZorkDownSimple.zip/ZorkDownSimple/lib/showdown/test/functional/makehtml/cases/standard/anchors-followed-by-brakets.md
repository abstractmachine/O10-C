This is a [link](https://en.wikipedia.org/wiki/Textile) (some other text)

This is a [link](https://en.wikipedia.org/wiki/Textile_(markup) (some other text)

This is a [link](https://en.wikipedia.org/wiki/Textile_(markup_language)) (some other text)

This is a [link](https://en.wikipedia.org/wiki/Textile_(markup_language)/foo) (some other text)
