This is \*an asterisk which should stay as is.
