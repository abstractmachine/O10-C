We love `<code> and &` for everything
