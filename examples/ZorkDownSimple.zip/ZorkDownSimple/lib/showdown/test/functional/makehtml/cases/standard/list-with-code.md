*   A list item with code:

        alert('Hello world!');
