Search the web at [Google][] or [Daring Fireball][].

Search the web at [Google] or [Daring Fireball].


  [Google]: http://google.com/
  [Daring Fireball]: http://daringfireball.net/
