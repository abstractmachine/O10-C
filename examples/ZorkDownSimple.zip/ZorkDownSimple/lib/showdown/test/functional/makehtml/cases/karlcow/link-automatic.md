This is an automatic link <http://www.w3.org/>
