``We love `code` for everything``
