![Alt text](/path/to/img.jpg)

![Alt text](/path/to/img.jpg "Optional title")

![Alt text][id]

![My Image]

![leave me alone]

![leave me alone][]

  [id]: url/to/image.jpg  "Optional title attribute"
  [My Image]: url/to/image2.jpg "Optional title attribute"
