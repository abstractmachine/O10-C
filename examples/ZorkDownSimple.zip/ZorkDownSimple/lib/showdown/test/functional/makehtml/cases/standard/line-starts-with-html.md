<a href="foo">some text</a> words

<br> words
