[Declare options](#Declare)

[Declare options](#Declare%20current%20operation%20options)

[Declare options](<#Declare current operation options>)

[Common Mark Example](https://spec.commonmark.org/0.30/#example-500)

[Common Mark Example](spec.commonmark.org/0.30/#example-500)