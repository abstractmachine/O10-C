 This is a paragraph with a trailing and leading space. 
