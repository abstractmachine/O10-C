Hello.this\_is\_a\_variable
and.this.is.another_one
