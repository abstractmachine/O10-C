 1.  Red
 1.  Green
 1.  Blue
