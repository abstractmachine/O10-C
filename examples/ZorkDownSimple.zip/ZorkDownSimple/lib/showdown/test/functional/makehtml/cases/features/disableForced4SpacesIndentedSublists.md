* foo
  * bar

---

* baz
  1. bazinga
