*   A list item with a blockquote:

    > This is a blockquote
    > inside a list item.
