An ampersand & in the text flow is escaped as an html entity.
