a ___strong and em___ thingy

bar___bazinga___bar

a ***strong and em*** thingy

bar***bazinga***bar
