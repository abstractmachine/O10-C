   This is a paragraph with 3 leading spaces.
