this email <foobar@example.com> should not be encoded
