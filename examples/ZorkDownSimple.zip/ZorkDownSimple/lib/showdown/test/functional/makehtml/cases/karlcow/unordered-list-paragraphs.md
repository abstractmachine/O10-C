* list item in paragraph

* another list item in paragraph
