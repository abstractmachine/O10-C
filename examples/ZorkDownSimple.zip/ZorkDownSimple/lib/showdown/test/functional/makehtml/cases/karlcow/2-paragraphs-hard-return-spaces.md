This is a first paragraph,
on multiple lines.
     
This is a second paragraph.
There are spaces in between the two.
