this is some text

```php
function thisThing() {
  echo "some weird formatted code!";
}
```

some other text
