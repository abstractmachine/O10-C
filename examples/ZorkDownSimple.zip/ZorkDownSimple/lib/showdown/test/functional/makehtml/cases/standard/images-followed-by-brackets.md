![image link](<./image/cat1.png>)(some text between brackets)

![image link](<./image/cat(1).png>)(some text between brackets)
