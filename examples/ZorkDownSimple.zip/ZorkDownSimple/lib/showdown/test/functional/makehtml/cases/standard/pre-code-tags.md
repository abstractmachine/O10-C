<pre>
<code>
foobar
</code>
</pre>

blabla

<pre nhaca="zulu"><code bla="bla">
foobar
</code>
</pre>

<pre><code>
<div>some html code</div>
</code></pre>
