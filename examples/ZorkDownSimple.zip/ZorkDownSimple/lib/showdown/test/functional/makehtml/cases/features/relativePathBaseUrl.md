[inline relative linky](that_dude_mike.js)

[inline absolute linky](ftp://wikis.com/micky.txt)

[global relative linky][relative_linky]

[global absolute linky][absolute_linky]

![inline relative image](mona-lisa.png)

![inline absolute image](http://images.com/mona-lisa.png)

![global relative image][relative_image]

![global absolute image][absolute_image]

[just an anchor](#holdin_it_down)

[relative_linky]: painters/Michelangelo.html
[relative_image]: ./mona-lisa.png
[absolute_linky]: https://www.my-wikis-site.com/peeps/Michelangelo.html
[absolute_image]: https://www.my-photo-site.com/mona-lisa.png
