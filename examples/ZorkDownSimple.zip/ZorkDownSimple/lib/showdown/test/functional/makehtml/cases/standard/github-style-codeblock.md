
Define a function in javascript:

```
function MyFunc(a) {
    var s = '`';
}
```

And some HTML

```html
<div>HTML!</div>
```

And some CSS with spaces before the language declaration

```    css
body {
    font-size: 1.5em;
}
```

Use more than 3 backticks

`````
some code
`````

Use tilde as delimiter

~~~
another piece of code
~~~
