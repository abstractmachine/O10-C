    //**this** code _has_ special chars
    var arr = ['foo', 'bar', 'baz'];
    function () {
        return 'foo';
    }
    \n
