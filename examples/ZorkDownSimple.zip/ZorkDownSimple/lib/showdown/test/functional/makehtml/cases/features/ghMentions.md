hello @tivie how are you?

this email foo@gmail.com is not parsed

this \@mentions is not parsed

@john.doe

@john-doe

@john_doe

@.johndoe

@_johndoe

@-johndoe

@johndoe.

@johndoe-

@johndoe_
