*   This is a list item
    with the content on
    multiline and indented.
*   And this another list item
    with the same principle.
