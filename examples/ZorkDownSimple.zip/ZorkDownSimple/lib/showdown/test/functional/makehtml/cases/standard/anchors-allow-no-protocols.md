[link](/uri)

[link](http://example.com/)

[link](http://example.com)

[link](https://example.com)

[link](https://example.com/)

[link](example.com)

[link](www.example.com)

[link](file://example.com)

[link](file://www.example.com)

[link](example.jpg)

[link](example.io)

[百度](http://baidu.com "百度")