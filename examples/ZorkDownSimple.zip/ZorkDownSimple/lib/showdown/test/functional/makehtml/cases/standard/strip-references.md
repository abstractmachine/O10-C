[1]: http://www.google.co.uk

[http://www.google.co.uk]: http://www.google.co.uk





[1]: http://dsurl.stuff/something.jpg

[1]:http://www.google.co.uk

 [1]:http://www.google.co.uk
