HTML entities are written using ampersand notation: &copy;
