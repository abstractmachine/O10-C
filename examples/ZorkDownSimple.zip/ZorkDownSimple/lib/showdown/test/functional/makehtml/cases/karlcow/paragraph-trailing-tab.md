This is a paragraph with 1 trailing tab.	
