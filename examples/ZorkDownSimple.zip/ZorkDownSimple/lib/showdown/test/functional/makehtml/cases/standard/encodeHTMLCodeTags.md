this is code <code>some <span>text</span></code> yeah!

<pre><code>
<div>foo</div>
</code></pre>
