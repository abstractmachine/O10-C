<style>
    p { line-height: 20px; }
</style>

An exciting sentence.
