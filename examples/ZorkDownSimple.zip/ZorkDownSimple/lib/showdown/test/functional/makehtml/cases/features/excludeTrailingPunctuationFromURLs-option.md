url http://www.google.com.

url http://www.google.com!

url http://www.google.com? foo

url (http://www.google.com) bazinga

url [http://www.google.com] bazinga

url http://www.google.com, bar
