 - This line spans
 more than one line and is lazy
 - Similar to this line
